import { createRouter ,createWebHashHistory} from "vue-router"

import LoginPage from '../page/login/LoginPage.vue'    //登录页面
import UserSignInPage from '../page/login/UserSignInPage.vue'  //用户注册页面
import ManagerSignInPage from '../page/login/ManagerSignInPage.vue' //管理员注册页面

import MainPage from '../page/login/MainPage.vue'    //    登录后进入的主页面

import LearningPage from '../page/login/LearningPage.vue'  //  学习页面
import ReviewPage from  '../page/login/ReviewPage.vue'     //   复习页面
import ShowStats from '../page/login/ShowStats.vue'      //信息统计页面
import SettingsPage from '../page/login/SettingsPage.vue'  //设置页面

import ManagerPage from '../page/login/ManagerPage.vue'    //   管理员页面


import (createRouter)
const routes = [
   {//登陆界面

    path:'/',
    name:'LoginPage',
    component:()=>import(/*webpackChunkName:'Login'*/'@/page/login/LoginPage.vue')
},

{//登陆界面

  path:'/',
  name:'LoginPage',
  component:LoginPage
},

{/*用户注册页面*/

  path:'/Usersignin',
  name:'UserSignInPage',
  component: UserSignInPage
},

{/*管理员注册页面*/

path:'/Managersignin',
name:'ManagerSignInPage',
component: ManagerSignInPage
},

{/*登录后的主页面*/

  path:'/main',
  name:'MainPage',
  component: MainPage
},

{/*复习*/
path:'/main/ReviewPage',
name:'ReviewPage',
component: ReviewPage
},

{/*学习页面*/
path:'/main/Learning',
name:'LearningPage',
component: LearningPage
},


{/*信息统计页面*/
path:'/main/ShowStats',
name:'ShowStats',
component: ShowStats
},


{/*设置页面*/

path:'/main/SettingsPage',
name:'SettingsPage',
component: SettingsPage
},
{/*管理员页面*/
path:'/main/SettingsPage/ManagerPage',
name:'ManagerPage',
component:  ManagerPage
},
]

  const router = createRouter({
    // 4. 内部提供了 history 模式的实现。为了简单起见，我们在这里使用 hash 模式。
    history: createWebHashHistory(),
    routes
  })

  export default router