import { createApp } from 'vue'

import router from './router/index.js'

import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'
import App from './App.vue'

//全局引入
import '../src/style/headtap.css'

import axios from 'axios'

axios.defaults.baseURL=""
const app = createApp(App)
app.use(router)

app.use(ElementPlus, {
    locale: zhCn,
  })
app.mount('#app')
