<template>
  <div class="container">
    <div class="header">
      <h1>管理员页面</h1>
    </div>

    <div class="content">
      <div class="form-group">
        <button class="btn-view-users" @click="viewUsers">查看已注册用户</button>
      </div>
      
      <div class="form-group">
        <button class="btn-clear-unused" @click="clearUnused">清除长时间未登录用户</button>
      </div>
      
      <div class="form-group">
        <button class="btn-add-vocabulary" @click="addVocabulary">添加词汇</button>
        <button class="btn-edit-vocabulary" @click="editVocabulary">编辑词汇</button>
        <button class="btn-delete-vocabulary" @click="deleteVocabulary">删除词汇</button>
        <button class="btn-search-vocabulary" @click="searchVocabulary">查找词汇</button>
      </div>

      <div class="form-group">
        <button class="btn-back" @click="backToHome">返回主页面</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'ManagePage',
  methods: {
    viewUsers() {
      // 处理“查看已注册用户”按钮的点击事件
    },
    clearUnused() {
      // 处理“清除长时间未登录用户”按钮的点击事件
    },
    addVocabulary() {
      // 处理“添加词汇”按钮的点击事件
    },
    editVocabulary() {
      // 处理“编辑词汇”按钮的点击事件
    },
    deleteVocabulary() {
      // 处理“删除词汇”按钮的点击事件
    },
    searchVocabulary() {
      // 处理“查找词汇”按钮的点击事件
    },
    backToHome() {
      // 处理“返回主页面”按钮的点击事件
      
    },
  },
};
</script>

<style scoped>
.container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  background-color: #f8f8f8;
  border-radius: 5px;
}

.header {
  margin-bottom: 20px;
  text-align: center;
}

.form-group {
  margin-bottom: 10px;
}

.btn-view-users,
.btn-clear-unused,
.btn-add-vocabulary,
.btn-edit-vocabulary,
.btn-delete-vocabulary,
.btn-search-vocabulary,
.btn-back {
  display: block;
  width: 100%;
  padding: 10px;
  border: none;
  border-radius: 5px;
  background-color: #007bff;
  color: #fff;
  text-align: center;
  font-size: 16px;
  cursor: pointer;
}

.btn-view-users:hover,
.btn-clear-unused:hover,
.btn-add-vocabulary:hover,
.btn-edit-vocabulary:hover,
.btn-delete-vocabulary:hover,
.btn-search-vocabulary:hover,
.btn-back:hover {
  background-color: #0062cc;
}
</style>
