

<template>
  <div id="backcont">
   <div class="a_content">
    <div class="login_cont">
      <div class="a_title">英语单词练习系统
        <div class="user">
          <p>账号</p>
          <el-input v-model="username" clearable=true class= "inputflex"   placeholder="请输入账号" />
        </div>

        <div class="user">
          <p>密码</p>
          <el-input v-model="password" class= "inputflex" type="password"  placeholder="请输入密码" />
        </div>

        <!--登陆和注册按钮的切换 --><!--点击事件 -->
        <div class="reg_view"  @click="regi= regi=='注册'?'登陆':'注册'">
          <p>{{ regi}}</p>
        </div>
        <!--两个按钮 -->
        
          <el-button v-if="regi == '注册'" @click="login" type="success" class="button">登陆</el-button> 
          <el-button v-else @click="signin" type="success" class="button">注册</el-button>     
      </div>
    </div>
   </div>
  </div>
</template>



<script>

import { reactive ,toRefs} from 'vue';
import axios from 'axios';
import router from '@/router/index.js';
import { ElMessage } from 'element-plus';

export default{

  
  setup(){
    const user = reactive({
      username:'',
      password:'',
      regi:'注册'
    })

//登陆
const login=()=>{
 if(!user.username||!user.password){
  ElMessage('用户名或密码不能为空！')
  return
}


//let data=qs.stringify({username :user.username, psaaword:user.password})
axios.get("http://localhost:8088/users").then(function(response){ 
console.log(response)
  if(response.data){
    alert('获取数据成功！')
  }
  else{alert('获取数据失败！')} 
})

router.push({ name: 'MainPage' })  
}
//注册



const signin=()=>{

  router.push({ name: 'UserSignInPage' })  //进入注册页面

}



    return {...toRefs(user),signin,login}
  }
}
</script>




<style>

</style>