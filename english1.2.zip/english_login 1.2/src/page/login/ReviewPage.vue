<template>
    <div class="review">
      <h2>复习</h2>
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>词本</th>
              <th>单词</th>
              <th>认识程度</th>
              <th>学习时间</th>
              <th>剩余复习次数</th>
            </tr>
          </thead>

        </table>
      </div>
      <div class="buttons-container">
        <button @click="sortByTime">按时间排序</button>
        <button @click="sortByReviews">按剩余复习次数排序</button>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    methods: {
      sortByTime() {
        this.sortBy = 'time';
      },
      sortByReviews() {
        this.sortBy = 'reviews';
      },
    },
  };
  </script>
  
  <style>
  .review {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
  }
  
  h2 {
    font-size: 32px;
    margin-bottom: 20px;
  }
  
  .table-container {
    max-height: 400px;
    overflow-y: auto;
  }
  
  .table {
    width: 100%;
}
</style>  