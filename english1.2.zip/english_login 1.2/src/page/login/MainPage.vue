<template>
  <div id="backcont">
  <div class="container">
    <div class="header">
      <h1>词汇学习应用</h1>
      <div class="settings-btn">
        <button @click="showSettings">设置</button>
        <button class="btn-start" @click="reviewing">查看需要复习单词</button>
      </div>
    </div>

    <div class="form">
      <div class="form-group">
        <label for="select-book">选择词本</label>
        <select id="select-book" v-model="selectedBook">
          <option value="">请选择</option>
          <option value="cet-4">四级</option>
          <option value="cet-6">六级</option>
          <option value="toefl">托福</option>
          <option value="ielts">雅思</option>
        </select>
      </div>

      <div class="form-group">
        <label for="select-action">选择操作</label>
        <select id="select-action" v-model="selectedAction">
          <option value="">请选择</option>
          <option value="start">开始学习</option>
          <option value="continue">继续学习</option>
        </select>
      </div>

      <div class="form-group">
        <button class="btn-start" @click="startLearning">开始学习</button>
  
        <button class="btn-stats" @click="showStats">学习信息统计</button>
      </div>
    </div>
  </div>
</div>
</template>


  
  <script>

import router from '@/router/index.js';

  export default {
    data() {
      return {
        selectedBook: '',
        selectedAction: '',
      };
    },
    methods: {
      reviewing(){
      router.push({name:"ReviewPage"})
      },
       showSettings() {
        router.push({ name: 'SettingsPage' })  //进入设置页面
      },
     
      showStats() { 
        router.push({ name: 'ShowStats' })  //进入数据统计页面页面
      },
     
      startLearning() {
        if (this.selectedAction && !this.selectedBook) {
          alert('请选择词本');
        } else {
            if(this.selectedAction=="开始学习"){
           //在数据库englishword中的表“username”_message中插入数据：

            }
            else if(this.selectedAction=="继续学习"){
            //依据词本名：查找最大的已学习单词数，在数据库中插入数据：
            }

            router.push({ name: 'LearningPage' })  //进入设置页面
        }
      },
    },
  };
  </script>
  <style>


  .container {
    position: absolute;      /* 定位，垂直集中   */
    top: 50%;
    left: 50%;
    transform: translate(-50%,-50%);

    max-width: 800px;
    padding: 20px;
    background-color: #f8f8f8;
    border-radius: 5px;
  }

  .header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
  }

  .header h1 {
    margin: 0;
    font-size: 32px;
    font-weight: 700;
    color: #333;
  }

  .settings-btn button {
    background-color: #4c34c6;
    border: none;
    font-size: 16px;
    color: #333;
    cursor: pointer;
    padding: 10px 15px;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  }

  .form {
    display: flex;
    flex-direction: column;
    gap: 20px;
  }

  .form-group label {
    font-size: 18px;
    font-weight: 500;
    color: #333;
    margin-bottom: 5px;
    display: block;
  }

  .form-group select {
    font-size: 16px;
    color: #333;
    padding: 10px 15px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #fff;
    width: 100%;
    box-sizing: border-box;
  }

  .btn-start {
    background-color: #007bff;
    border: none;
    font-size: 16px;
    color: #fff;
    cursor: pointer;
    padding: 10px 15px;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  }

  .btn-start:hover {
    background-color: #0069d9;
  }

  .btn-stats {
    background-color: #28a745;
    border: none;
    font-size: 16px;
    color: #fff;
    cursor: pointer;
    padding: 10px 15px;
    border-radius: 5px;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  }

  .btn-stats:hover {
    background-color: #218838;
  }
</style>
