
<template>
    <div class="change-info">
      <h3>修改个人信息</h3>
      <form>
        <div class="form-group">
          <label for="username">用户名：</label>
          <input type="text" id="username" v-model="username" required>
        </div>
        <div class="form-group">
          <label for="password">密码：</label>
          <input type="password" id="password" v-model="password" required>
        </div>
        <div class="form-group">
          <label for="email">邮箱：</label>
          <input type="email" id="email" v-model="email" required>
        </div>
        <div class="form-group">
          <label for="phone">手机号：</label>
          <input type="tel" id="phone" v-model="phone" required>
        </div>
        <button type="submit" @click.prevent="submit">提交</button>
      </form>
    </div>
 
  </template>
  
  <script>
  export default {
    data() {
      return {
        username: '',
        password: '',
        email: '',
        phone: ''
      };
    },
    methods: {
      submit() {
        // submit form data
      }
    }
  };
  </script>
  
  <style scoped>
  .change-info {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
  }
  
  .form-group {
    margin-bottom: 10px;
  }
  
  label {
    display: inline-block;
    width: 80px;
  }
  </style>