
<template>
  <div class="learning">
    <h2 class="learning-title">Learning</h2>
    <p class="lesson">{{ currentLesson }}</p>
    <div class="learning-buttons">
      <button class="details-btn" @click="showDetails">显示详情</button>
      <button class="next-btn" @click="lastLesson">上一个</button>
      <button class="next-btn" @click="nextLesson">下一个</button>
    </div>
    <div class="knowledge-select">
      <label for="select-knowledge">你是否认识这个单词？</label>
      <select id="select-knowledge" v-model="knowledge">
        <option value="know">认识</option>
        <option value="fuzzy">模糊</option>
        <option value="dont-know">不认识</option>
      </select>
    </div>
    <div class="learned-count">
      <label for="input-count">已学习单词数量：</label>
      <input type="number" id="input-count" v-bind:value="learnedCount" readonly>
    </div>
  </div>
</template>
<script>
export default {
  data() {

    return {
      currentLesson: 'Lesson 1',
      knowledge: 'know',
      learnedCount: 50
    };
  },
  methods: {
    showDetails() {
      // show details logic
    },
    lastLesson() {
      // go to next lesson logic
      this.learnedCount-=1
    },
    nextLesson() {
      // go to next lesson logic
      this.learnedCount+=1
    }
  }
};
</script>
<style>
.learning {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  background-color: #f8f8f8;
}

.learning-title {
  font-size: 32px;
  margin-bottom: 20px;
}

.lesson {
  font-size: 24px;
  margin-bottom: 20px;
}

.learning-buttons {
  display: flex;
  justify-content: space-between;
  width: 300px;
  margin-bottom: 20px;
}

.details-btn {
  background-color: #f0ad4e;
  color: #fff;
  border: none;
  border-radius: 5px;
  padding: 10px 20px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.details-btn:hover {
  background-color: #ec971f;
}

.next-btn {
  background-color: #5cb85c;
  color: #fff;
  border: none;
  border-radius: 5px;
  padding: 10px 20px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.next-btn:hover {
  background-color: #449d44;
}

.knowledge-select {
  display: flex;
  flex-direction: column;
  align-items: center;
}

label {
  font-size: 20px;
  margin-bottom: 10px;
}

select {
  font-size: 16px;
  padding: 5px;
  border-radius: 5px;
  border: 1px solid #ccc;
}

.learned-count {
  margin-top: 20px;
}

input[type="number"] {
  font-size: 16px;
  padding: 5px;
  border-radius: 5px;
  border: 1px solid #ccc;
}
</style>