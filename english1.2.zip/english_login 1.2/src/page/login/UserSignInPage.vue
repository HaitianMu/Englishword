<template>
    <div id="backcont">
      <div class="a_content">
        <div class="sign_cont">
          <div class="a_title">{{ title }}
  
          <div class="user">
            <p>用户名</p>
            <el-input v-model="username" clearable=true class="inputflex" placeholder="请输入用户名" />
          </div>
  
          <div class="user">
            <p>密码</p>
            <el-input v-model="password" class="inputflex" type="password" placeholder="请输入密码" />
          </div>
  
          <div class="user">
            <p>确认密码</p>
            <el-input v-model="confirmPassword" class="inputflex" type="password" placeholder="请确认密码" />
          </div>
  
          <div class="user">
            <p>邮箱</p>
            <el-input v-model="email" class="inputflex" type="email" placeholder="请输入邮箱" />
          </div>
            <div class="user">
            <p>请输入手机号</p>
            <el-input v-model="email" class="inputflex" type="phone" placeholder="请输入手机号" />
          </div>
  
          <div class="reg_view" @click="toggleForm">{{ toggleText }}</div>
  
          <el-button @click="register" type="success" class="button">{{ buttonText }}</el-button>
          <el-button @click="ManagerSign" type="success" class="button2">管理员注册</el-button>
        </div>
    </div>
      </div>
    </div>
  </template>
  
  <script>
  import { reactive, toRefs } from 'vue';
  import router from '@/router/index.js';
  import axios from 'axios';
  import qs from 'qs';

  export default {
    name: 'UserSignInPage',
  methods: {
    ManagerSign(){
   router.push({name:"ManagerSignInPage"})
    }
  },
    
    setup() {
      const formType = reactive({
        title: '用户注册',
        toggleText: '已有账号，去登陆',
        buttonText: '注册',
      });
  
      const user = reactive({
        username: '',
        password: '',
        confirmPassword: '',
        email: '',
      });
  
      const toggleForm = () => {
        router.push({ name: 'LoginPage' })  //进入登录页面
      };
  
      const register = () => {

        console.log(user.username, user.password, user.confirmPassword, user.email);
  
        if (user.password !== user.confirmPassword) {
          alert('两次输入密码不一致，请重新输入！');
          return;
        }
  
        const data = qs.stringify({
          username: user.username,
          password: user.password,
          email: user.email,
        });
  
        axios.post(qs.parse('http://localhost:8088/signin'), data).then(function(response) {
          if (response.data) {
            alert('注册成功！');

            // Redirect to login page
          } else {
            alert('注册失败！');
          }
        });
        
      };
  
      return {
        ...toRefs(user),
        ...toRefs(formType),
        toggleForm,
        register,
      };
    },
  };
  </script>
  
  <style scoped>
.button2{
  height: 37.5px;
    width: 150px;
    display: flex;      /* 弹性布局 */
    align-items: center;/* 排到布局的中间  */
    justify-content: center; /* 如何分配空间 */
    margin: 10px auto 0 auto;/*外边距  */
    font-size: 15px;
}
.sign_cont{

width:750px;             
height:600px;
background: #d6ecf0;
border-radius: 5px;
}

  </style>