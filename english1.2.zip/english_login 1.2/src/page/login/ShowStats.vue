<template>
    <div class="stats">
      <h2>学习信息统计</h2>
      <table>
        <thead>
          <tr>
            <th>词本</th>
            <th>已学习单词数</th>
            <th>已复习单词数</th>
            <th>未学习单词数</th>
            <th>学习进度</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>CET-4</td>
            <td>1500</td>
            <td>1000</td>
            <td>500</td>
            <td>75%</td>
          </tr>
          <tr>
            <td>CET-6</td>
            <td>2000</td>
            <td>1500</td>
            <td>500</td>
            <td>80%</td>
          </tr>
          <tr>
            <td>TOEFL</td>
            <td>1000</td>
            <td>700</td>
            <td>300</td>
            <td>70%</td>
          </tr>
          <tr>
            <td>IELTS</td>
            <td>1800</td>
            <td>1200</td>
            <td>600</td>
            <td>66.67%</td>
          </tr>
        </tbody>
      </table>
    </div>
  </template>
  
  <style>
  .stats {
    padding: 20px;
  }
  
  table {
    border-collapse: collapse;
    width: 100%;
    margin-top: 20px;
    text-align: center;
  }
  
  th, td {
    padding: 10px;
    border: 1px solid #5923a5;
  }
  
  th {
    background-color: #c7cd0d;
    font-weight: bold;
  }
  </style>
  