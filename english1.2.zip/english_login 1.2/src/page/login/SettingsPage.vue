<template>
  <div class="container">
    <div class="header">
      <h1>个人设置</h1>
    </div>

    <div class="content">
      <div class="form-group">
        <button class="btn-settings" @click="editProfile">修改个人设置</button>
      </div>
      
      <div class="form-group">
        <button class="btn-switch" @click="switchAccount">切换账号</button>
      </div>
      
      <div class="form-group">
        <button class="btn-logout" @click="logout">退出登录</button>
      </div>
      <div class="form-group">
    <button class="btn-admin" @click="switchToAdminPage">切换至管理员页面</button>
  </div>
    </div>
  </div>
</template>

<script>

import router from '@/router/index.js'
export default {
  name: 'SettingPage',
  methods: {
    editProfile() {
      // 处理“修改个人设置”按钮的点击事件
    },
    switchAccount() {
      // 处理“切换账号”按钮的点击事件
    },
    logout() {
      // 处理“退出登录”按钮的点击事件
    },
    switchToAdminPage(){
      router.push({name: 'ManagerPage'})
      //切换至管理员页面
    }
  },
};
</script>

<style scoped>
.container {
  max-width: 600px;
  margin: 0 auto;
  padding: 20px;
  background-color: #f8f8f8;
  border-radius: 5px;
}

.header {
  margin-bottom: 20px;
  text-align: center;
}

.form-group {
  margin-bottom: 10px;
}

.btn-settings,
.btn-switch,
.btn-logout {
  display: block;
  width: 100%;
  padding: 10px;
  border: none;
  border-radius: 5px;
  background-color: #007bff;
  color: #fff;
  text-align: center;
  font-size: 16px;
  cursor: pointer;
}

.btn-settings:hover,
.btn-switch:hover,
.btn-logout:hover {
  background-color: #0062cc;
}
</style>
